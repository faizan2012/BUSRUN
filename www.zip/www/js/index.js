/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
//var app = {
    document.addEventListener('deviceready', function(){
        let config = {
            key: 'game',
            type: Phaser.AUTO,
            scale: {
                mode: Phaser.Scale.FIT,
                parent: 'phaser-example',
                autoCenter: Phaser.Scale.CENTER_BOTH;
                width: 400,
                height: 900
            }
            pixelArt: true,
            physics: {
                default: 'arcade',       
                arcade: {
                    debug: false,
                    gravity: {y: 0}
                },
                /*matter: {
                    debug: true,
                    gravity: {y:0}
                }*/
            },
            scene: [Menu, Spawn, GameOver]
        };


        /*class Game extends Phaser.Game {

            constructor(){
                super(config);

                this.scene.add('Menu', Menu, false);
                this.scene.add('Spawn', Spawn, false);

                this.scene.start('Menu');
            }
        }
        new Game();*/
        let bank = localStorage.getItem('bal');
        //bank is set to the value of bal, retaining the coins the players have gathered
        bank = parseInt(bank, 10);
        const Epsilon = 0.00000001;
        var game = new Phaser.Game(config);
    });

//};

//app.initialize();