let config = {
    key: 'game',
    type: Phaser.AUTO,
    scale: {
        mode: Phaser.Scale.FIT,
        parent: 'phaser-example',
        autoCenter: Phaser.Scale.CENTER_BOTH,
        width: 400,
        height: 900
    },
    pixelArt: false,
    physics: {
        default: 'arcade',       
        arcade: {
            debug: false,
            gravity: {y: 0}
        },
        /*matter: {
            debug: true,
            gravity: {y:0}
        }*/
    },
    scene: [Load, Menu, Spawn, Shop, GameOver]
};


/*class Game extends Phaser.Game {

    constructor(){
        super(config);

        this.scene.add('Menu', Menu, false);
        this.scene.add('Spawn', Spawn, false);

        this.scene.start('Menu');
    }
}
new Game();*/
let bank;
function account(){
    account.didrun = localStorage.getItem('acc');
    if(account.didrun != 'yes'){
        localStorage.setItem('acc', 'yes');
        localStorage.setItem('bus2', 'locked');
        localStorage.setItem('bus3', 'locked');
        localStorage.setItem('bus4', 'locked');
        localStorage.setItem('bus5', 'locked');
        localStorage.setItem('bus6', 'locked');
        localStorage.setItem('skin', '0');
        localStorage.setItem('bal', '0');
        account.didrun = localStorage.getItem('acc');
    }
    bank = localStorage.getItem('bal');
}
account();
//bank is set to the value of bal, retaining the coins the players have gathered
bank = parseInt(bank, 10);
const Epsilon = 0.00000001;
var game = new Phaser.Game(config);