class GameOver extends Phaser.Scene{
	constructor(loser, pointsUI, coinsUI, loss, whoosh){
		super('gameover');
		this.loser = loser;
		this.pointsUI = pointsUI;
		this.coinsUI = coinsUI;
		this.loss = loss;
		this.whoosh = whoosh;
	}

	create(){
		this.f = 0;
		this.points = 0;
		this.count = 0;
		this.coins = bank - Spawn.allowance;
		var writing = {
			font: '20px Lucida Console',
			fill: '#ffffff'
		}
        this.loss = this.sound.add('loss');
		this.loss.play();
		this.whoosh = this.sound.add('whoosh');
		var collider = this.physics.add.image(200, 915, 'collider').setAlpha(0).setScale(0.3);
		collider.setGravityY(0);
		collider.setImmovable(true);
		this.loser = this.physics.add.sprite(200, -660, 'loser').setScale(0.75);
		this.loser.setGravityY(3000);
		this.loser.setBounce(0.2);
		this.physics.add.collider(this.loser, collider);
		this.time.addEvent({
			delay: 1500,
			callback:() => {
				this.pointsUI = this.add.text(255, 423, this.points, writing);
				this.coinsUI = this.add.text(255, 340, this.count, writing);
				var restart = this.add.circle(140, 710, 40);
				this.buttonConfig(restart);
				restart.on('pointerdown', () => {
					this.panAway(restart,0,-2000);
					game.scene.resume('menu');
			        game.scene.start('spawn');

				})

				var shop = this.add.circle(275, 710, 40);
				this.buttonConfig(shop);
				shop.on('pointerdown', (pointer)=>{
					this.panAway(shop,-2000,0);
					game.scene.start('shop');
				})

			repeat: 0
			},
		})
	}

	buttonConfig = function(button){
		button.inputEnabled = true;
		button.setInteractive();
	}
	panAway = (button,x,y)=>{
		this.loss.pause();
		this.whoosh.play();
		this.loser.setGravityY(0);
		this.loser.setVelocityY(y);
		this.loser.setVelocityX(x);
		this.pointsUI.destroy();
		this.coinsUI.destroy();
		button.destroy();
		game.scene.stop('gameover');
		game.scene.stop('spawn');	        
	}

	update(){
		this.f++;
		if(this.f > 90){
			if (this.points < Spawn.score){
				this.points += 100;
				this.pointsUI.setText(this.points);
			}
			if(this.count < this.coins){
				this.count++;
				this.coinsUI.setText(this.count);
			}
		}
		if(this.loser.y < -660){
			game.scene.pause('gameover');
		}
	}
}