let matConfig = {
    key: 'spawn',
    type: Phaser.AUTO,
    pixelArt: false,
    physics: {                
        matter: {
            debug: false,
            gravity:{y:0}
        }
    }
} 



let value = 10;
let hold = 0;
const HOLDCAP = 50;
const SPEED = 0.15;
var counter = 0;

class Spawn extends Phaser.Scene {
    constructor(counter){
        super(matConfig);
        this.counter = counter;
    }

    create(){
        this.counter = 0;
        Menu.bankText.setText(bank);
        Spawn.allowance = bank;

        Spawn.score = 0;
        Spawn.bgm = this.sound.add('bgm');

        switch(parseInt(Menu.skin,10)){
            case 0:
                Spawn.bus = this.matter.add.image(200,725,'bus').setScale(0.25);
                break;
            case 1:
                Spawn.bus = this.matter.add.image(200,725,'bus2').setScale(0.25);
                break;
            case 2:
                Spawn.bus = this.matter.add.image(200,725,'bus3').setScale(0.25);
                break;
            case 3:
                Spawn.bus = this.matter.add.image(200,725,'bus4').setScale(0.25);
                break;
            case 4:
                Spawn.bus = this.matter.add.image(200,725,'bus5').setScale(0.25);
                break;
            case 5:
                Spawn.bus = this.matter.add.image(200,725,'bus6').setScale(0.25);
                break;
            default:
                Spawn.bus = this.matter.add.image(200,725,'bus').setScale(0.25);
        }
        Spawn.bus.setFrictionAir(0);
        Spawn.bus.setBody({
            type: 'rectangle',
            width: 45,
            height: 205,
        });
        Spawn.bus.setMass(Infinity);

        Spawn.scoreUI = this.add.text(25,25, 'Score ' + 0, {font: '16px Lucida Console'});

        Spawn.oncoming = this.time.addEvent({
            //cars will appear every 3 seconds
            delay: 3000,
            callback: function(){
                //CREATING CARS
                //random cars
                this.spawnCar(-200);
                if(Spawn.score > 2000){
                    this.spawnCar(Phaser.Math.Between(-500, -400));
                }

                //coins
                this.spawnCoin();

                //fuel
                this.spawnFuel(Phaser.Math.Between(-550, -950));

            },
            callbackScope: this,
            repeat: -1
        });

        const currency = this.add.sprite(320,33,'coinSpin', 'Gold_21.png').setScale(0.04);
        currency.play('coinToss');

        Spawn.cursors = this.input.keyboard.createCursorKeys();

        this.add.image(35, 150, 'fuelindicator').setScale(0.45);

        Spawn.rect = this.add.rectangle(35, 150, 8, 165, 0x99ff33).setRotation(3.14);

        Spawn.rect2 = this.add.rectangle(35,67,0,18);

        Spawn.particles = this.add.particles('whiteFlare');

        Spawn.emitter = Spawn.particles.createEmitter({
            speed: 100,
            scale: {start: 0.015, end: 0},
            gravityY: -1500,
            blendMode: "ADD"
        })

        Spawn.emitter.startFollow(Spawn.rect2);
        var coinSfx = this.sound.add('pickup');
        var revSfx = this.sound.add('rev');

        this.matter.world.on('collisionstart', (event)=> {
            var pairs = event.pairs;
            
            for(var i = 0; i<pairs.length; i++){
                var bodyA = pairs[i].bodyA;
                var bodyB = pairs[i].bodyB;

                //coins has circle body as their label
                if(bodyA.mass === Infinity){
                    if(bodyB.label === "Circle Body"){
                        Spawn.coin.destroy();
                        bank += value;
                        Menu.bankText.setText(bank);
                        localStorage.setItem('bal', bank);
                        //value of bal set here in local storage
                        coinSfx.play();

                    }
                    //cars has rectangle body as their label
                    if(bodyB.label === "Rectangle Body"){
                        if(bodyB.mass === Epsilon){
                            Spawn.fuel.destroy();
                            Spawn.rect.height += 45;
                            Spawn.rect2.y -= 45;
                            revSfx.play();
                        }
                        else{
                            this.lose();
                        }
                    }
                }
            }
                /*This method of identifying objects may come prop up problems if we decide to add fuel or the such to the game
                It's kinda unintuitive, if we find a better way we can use it instead of the code here since.
                This is in the update method because the game suffers from huge amounts of lag if it's in the 
                update method and touching a coin would reward the player with thousands of coins.
                I figured out how to specify the object using console.log
                */
        });
    
        switch(Menu.controls){
            case 0:
                this.touch();
                break;
            case 1:
                this.tilt();
                break;
        }
    }
    //broke up the timed event code into functions
    spawnCar = function(x){
        Spawn.car = this.matter.add.image(Phaser.Math.Between(20, 380), x, 'cars', 'cars_0' + Phaser.Math.Between(1,6) + '.png').setScale(0.6).setDepth(0);

        Spawn.car.setBody({
            width: 50,
            height: 107
        })
        Spawn.car.setFrictionAir(0);
        Spawn.car.setVelocityY(11 + this.counter);
    }
    spawnCoin = function(){
        Spawn.coin = this.matter.add.image(Phaser.Math.Between(40,360), -500, 'coinSpin', 'Gold_21.png').setScale(0.05).setAlpha(0.9);
        Spawn.coin.setBody({
            type: 'circle',
            width: 30,
            height: 30
        });
        Spawn.coin.setFrictionAir(0);
        Spawn.coin.setVelocityY(10);
        Spawn.coin.setMass(Epsilon);
    }
    spawnFuel = function(x){
        Spawn.fuel = this.matter.add.image(Phaser.Math.Between(40, 360), x, 'fuel').setScale(0.18);
        Spawn.fuel.setBody({
            width: 30,
            height: 30
        })
        Spawn.fuel.setMass(Epsilon);
        Spawn.fuel.setFrictionAir(0);
        Spawn.fuel.setVelocityY(10);
    }
    lose = function(){
        Spawn.bgm.pause();
        game.scene.pause('menu');
        game.scene.pause('spawn');
        game.scene.start('gameover');
    }

    touch = function(){
        this.input.on('pointerdown', function(pointer){
            if(pointer.x >= 200){
                hold += 35;
            }
            else{
                hold -= 35;
            }
        });

        this.input.on('pointerup', function(pointer){
            hold = 0;
        });
        //Spawn.bus.setRotation(Spawn.bus.body.velocity.x/HOLDCAP);
    }

    

    tilt = function(){
        gyro.frequency = 1;
        //start gyroscope detection
        gyro.startTracking(function(o) {
            //updating bus velocity
            Spawn.bus.setVelocityX(o.gamma/10);
            Spawn.bus.setRotation(o.gamma/200);
        })
    }



    update(){
        Spawn.bus.y = 725
        switch(Menu.controls){
            case 0:
            Spawn.bus.setRotation(Spawn.bus.body.velocity.x/HOLDCAP);
        }
        //Spawn.bus.setRotation(Spawn.bus.body.velocity.x/HOLDCAP);
        Spawn.bus.setVelocityX(SPEED*hold);
        if(hold > HOLDCAP){
            hold = HOLDCAP;
        }
        else if(hold < -HOLDCAP){
            hold = -HOLDCAP;
        }

        this.counter += 0.002;

    
        if(Spawn.score%5000 == 0 && Spawn.score != 0){
            value += 5;
        }
        Spawn.rect.height -= 0.15;

        if(Spawn.rect.height < 1){
            Spawn.rect.height = 0;
            Spawn.emitter.setAlpha(0);
            this.lose();
        }
        if(Spawn.rect.height > 165){
            Spawn.rect.height = 165;
            Spawn.rect2.y = 67;
        }
        if(Spawn.rect.height < HOLDCAP){
            Spawn.rect.setFillStyle(0xcc0000);
        }
        if(Spawn.rect.height >= HOLDCAP){
            Spawn.rect.setFillStyle(0x99ff33);
        }
        Spawn.rect2.y += 0.15;

        if(Spawn.bus.x > 380){
            Spawn.bus.x = 380;
            hold = 0;
        }
        else if(Spawn.bus.x < 0){
            Spawn.bus.x = 0;
            hold = 0;
        }

        if(Spawn.score %5650 == 0){
            Spawn.bgm.play();
        }

        Spawn.score++;
        Spawn.scoreUI.setText('Score ' + Spawn.score);

    };

}