class Load extends Phaser.Scene{
	constructor(){
		super("load");
	}
	preload(){
		this.load.image('collider', 'js/matter/assets/collider.png');
        this.load.image('bus', 'js/matter/assets/buses/buses_1.png');
        this.load.image('road', 'js/matter/assets/road3.png');
        this.load.image('selfplug', 'js/matter/assets/zatori.png');
        this.load.image('touch', 'js/matter/assets/touch.png');
        this.load.image('coin', 'js/matter/assets/coin.png');
        this.load.atlas('anim', 'js/matter/assets/titleanim.png', 'js/matter/assets/titleanim.json');
        this.load.image('logo', 'js/matter/assets/bus.png');
        this.load.atlas('coinSpin', 'js/matter/assets/sprites.png', 'js/matter/assets/sprites.json');
        this.load.audio('bgm', 'js/matter/assets/bgm.mp3');
        this.load.image('icon', 'js/matter/assets/icon.png');
        this.load.image('icon2', 'js/matter/assets/icon2.png');
        this.load.atlas('cars', 'js/matter/assets/cars.png', 'js/matter/assets/cars.json');
        this.load.image('fuel', 'js/matter/assets/fuel.png');
        this.load.image('whiteFlare', 'js/matter/assets/white-flare.png');
        this.load.image('fuelindicator', 'js/matter/assets/fuelgauge.png');
        this.load.audio('pickup', 'js/matter/assets/p-ping.mp3');
        this.load.audio('rev', 'js/matter/assets/fuel.wav');
        this.load.image('road3', 'js/matter/assets/road3.png');
        this.load.image('loser', 'js/matter/assets/gameOver.png');
		this.load.audio('whoosh', 'js/matter/assets/whoosh.mp3');
		this.load.audio('count', 'js/matter/assets/score-count.wav');
        this.load.audio('loss', 'js/matter/assets/loss2.wav');
        this.load.image('bus2', 'js/matter/assets/buses/buses_2.png');
        this.load.image('bus3', 'js/matter/assets/buses/buses_3.png');
        this.load.image('bus4', 'js/matter/assets/buses/buses_4.png');
        this.load.image('bus5', 'js/matter/assets/buses/buses_5.png');
        this.load.image('bus6', 'js/matter/assets/buses/buses_6.png');
        this.load.image('bag', 'js/matter/assets/shopIcon.png');
        this.load.image('shop', 'js/matter/assets/shop.png');

	}
	create(){
		game.scene.start('menu');
	}
}