class Menu extends Phaser.Scene {

    constructor(){
        super('menu');
    }

    /*preload(){
        this.load.image('collider', 'js/matter/assets/collider.png');
        this.load.image('bus', 'js/matter/assets/bus-a.png');
        this.load.image('road', 'js/matter/assets/road3.png');
        this.load.image('selfplug', 'js/matter/assets/techholic.png');
        this.load.image('touch', 'js/matter/assets/touch.png');
        this.load.image('coin', 'js/matter/assets/coin.png');
        this.load.atlas('anim', 'js/matter/assets/titleanim.png', 'js/matter/assets/titleanim.json');
        this.load.image('logo', 'js/matter/assets/bus.png');
        this.load.atlas('coinSpin', 'js/matter/assets/sprites.png', 'js/matter/assets/sprites.json');
        this.load.audio('bgm', 'js/matter/assets/bgm.mp3');
        this.load.image('icon', 'js/matter/assets/icon.png');
        this.load.image('icon2', 'js/matter/assets/icon2.png');
    }*/
    create(){
        //ANIMATION
        this.anims.create({
            key:'shine',
            frames: this.anims.generateFrameNames(
                'anim',
            ),
            loop: Infinity
        });
        this.anims.create({
            key: 'coinToss',
            frames: this.anims.generateFrameNames(
                'coinSpin',
                {
                    prefix: "Gold_",
                    suffix: ".png",
                    start: 21,
                    end: 30,
                    zeroPad: 2,
                }
            ),
            repeat: -1
        });
        Menu.road = this.add.image(200,0,'road').setScale(1.01);
        var selfPlug = this.add.image(320,880, 'selfplug').setAlpha(0).setScale(0.085);
        Menu.skin = localStorage.getItem('skin');
        switch(parseInt(Menu.skin,10)){
            case 0:
                Menu.bus = this.physics.add.image(200,725,'bus').setScale(0.25);
                break;
            case 1:
                Menu.bus = this.physics.add.image(200,725,'bus2').setScale(0.25);
                break;
            case 2:
                Menu.bus = this.physics.add.image(200,725,'bus3').setScale(0.25);
                break;
            case 3:
                Menu.bus = this.physics.add.image(200,725,'bus4').setScale(0.25);
                break;
            case 4:
                Menu.bus = this.physics.add.image(200,725,'bus5').setScale(0.25);
                break;
            case 5:
                Menu.bus = this.physics.add.image(200,725,'bus6').setScale(0.25);
                break;
            default:
                Menu.bus = this.physics.add.image(200,725,'bus').setScale(0.25);
        }
        Menu.logo = this.physics.add.sprite(200,175,'anim').setScale(0.8);
        Menu.logo.setVelocity(0, 50);
        Menu.logo.setGravity(0,150);
        Menu.logo.setBounce(1);
    
        //options for controls, 0 for touch 1 for tilt
        //var switchFeed = this.add.text(50, 25, 'Touch Enabled', {font: '14px Lucida Console'});
        Menu.controls = 0;
        Menu.switch = this.add.image(45,33,'icon').setScale(0.2).setInteractive();
        Menu.switchG = this.add.image(45,33,'icon2').setScale(0.2).setInteractive().setAlpha(0);
    
        //Menu.logo.setGravity(0, 150);
        var startButt = this.add.image(200, 400,'touch').setScale(0.6);
    
    
        //COLLIDER BOTTOM
        var collide = this.physics.add.image(200, 300, 'collider').setScale(1).setAlpha(0);
        collide.setCollideWorldBounds(true);
        collide.body.immovable = true;

        //COLLIDERS
        this.physics.add.collider(Menu.logo, collide);

        //looping animation and duration 
        Menu.drive = this.tweens.add({
            targets: Menu.road,
            y: 900,
            duration:1500,
            loop: Infinity,
        });


        //Flashing in 
        this.tweens.add({
            targets: startButt,
            ease: 'Cubic',
            delay: 0,
            alpha: {
                getStart: () => 0.3,
                getEnd: () => 1,
            },
            yoyo: true,
            duration: 1000,
            loop: Infinity,
        });

        this.time.addEvent({
            delay: 3000,
            callback: this.animation,
            callbackScope: this,
            repeat: -1
        })

        var check = 0//stopping multiple mouse clicks from resetting Spawn scene, allows more friendly mouse and touch controls

        this.input.on('pointerdown', function(pointer){
            if(pointer.y > 60){
                if(check === 0){
                //Menu.drive.stop();
                //Menu.road.setAlpha(0);
                Menu.bus.destroy();
                game.scene.start('spawn', false, false);
                Menu.logo.setVelocity(0,-750);
                Menu.logo.setGravity(0,0);
                startButt.destroy();
                selfPlug.destroy();
                collide.destroy();
                Menu.switch.destroy();
                Menu.switchG.destroy();
                check++;
                //game.scene.stop('menu');
                }
            }
            else{
                switch(Menu.controls){
                    case 0:
                        Menu.controls=1;
                        Menu.switch.setAlpha(0);
                        Menu.switchG.setAlpha(1);
                        //switchFeed.setText('Tilt Enabled');
                        break;
                    case 1:
                        Menu.controls=0;
                        Menu.switch.setAlpha(1);
                        Menu.switchG.setAlpha(0);
                        //switchFeed.setText('Touch Enabled');
                        break;
                    default:
                        console.log(Menu.controls);
                };
            }
        })
        const currency = this.add.sprite(320,33,'coinSpin', 'Gold_21.png').setScale(0.04);
        Menu.bankText = this.add.text(340,25, bank, {font: '16px Lucida Console', fill: "#ffff00"});
        currency.play('coinToss');
        
    }

    animation(){
        Menu.logo.play('shine');
    }
}
