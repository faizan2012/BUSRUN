class Shop extends Phaser.Scene{
	constructor(){
		super("shop");
		this.font = {
			font: '16px Lucida Console',
			fill: '#ffff00',
			align: 'center'
		}
	}
	create(){
		let i;
		Shop.selection = 0;
		Shop.prices = ['Selected',
			2500,
			2500,
			5000,
			5000,
			5000
		];
		Shop.screen = this.physics.add.image(200, 450, 'shop').setScale(0.75);
		const back = this.add.rectangle(65,55,90,60).setInteractive();
		const left = this.add.rectangle(158, 645, 60, 80).setInteractive();
		const right = this.add.rectangle(235, 645, 60, 80).setInteractive();
		const purchase = this.add.rectangle(200,720,200,50).setInteractive();
		let coins = this.add.text(250,45, 'Coins = ' + bank, this.font);
		var pricetag = this.add.text(170,550, Shop.prices[Shop.selection], this.font);
		Shop.buses = [this.add.image(205,415,'bus'),
			this.add.image(205,415,'bus2'),
			this.add.image(205,415,'bus3'),
			this.add.image(205,415,'bus4'),
			this.add.image(205,415,'bus5'),
			this.add.image(205,415,'bus6')
		];
		let status = ['unlocked',
			localStorage.getItem('bus2'),
			localStorage.getItem('bus3'),
			localStorage.getItem('bus4'),
			localStorage.getItem('bus5'),
			localStorage.getItem('bus6')
		];

		for(i=0;i<Shop.buses.length;i++){
			Shop.buses[i].setScale(0.3);
			if(i>0){
				Shop.buses[i].setAlpha(0);
			};
		};
		back.on('pointerdown',()=>{
			Shop.screen.setVelocity(2000,0);
			game.scene.stop('shop');
			game.scene.start('gameover');
		});
		left.on('pointerdown',()=>{
			Shop.selection--;
			if(Shop.selection < 0){
				Shop.selection = 0;
			};
			Shop.buses[Shop.selection].setAlpha(1);
			Shop.buses[Shop.selection+1].setAlpha(0);
			this.label(pricetag, status);
			this.skin(status);
		});
		right.on('pointerdown',()=>{
			Shop.selection++;
			if(Shop.selection > 5){
				Shop.selection = 5;
			};
			Shop.buses[Shop.selection].setAlpha(1);
			Shop.buses[Shop.selection-1].setAlpha(0);
			this.label(pricetag, status);
			this.skin(status);
		});
		purchase.on('pointerdown', ()=>{
			if(bank >= parseInt(Shop.prices[Shop.selection], 10)){
				bank -= parseInt(Shop.prices[Shop.selection],10);
				localStorage.setItem('bal', bank);
				coins.setText('Coins = ' + bank);
				switch(Shop.selection){
					case 1:
						localStorage.setItem('bus2', 'unlocked');
						status[Shop.selection] = localStorage.getItem('bus2');
						Shop.prices[Shop.selection] = 'Selected';
						this.label(pricetag);
						break;
					case 2:
						localStorage.setItem('bus3', 'unlocked');
						status[Shop.selection] = localStorage.getItem('bus3');
						Shop.prices[Shop.selection] = 'Selected';
						this.label(pricetag);
						break;
					case 3:
						localStorage.setItem('bus4', 'unlocked');
						status[Shop.selection] = localStorage.getItem('bus4');
						Shop.prices[Shop.selection] = 'Selected';
						this.label(pricetag);
						break;
					case 4:
						localStorage.setItem('bus5', 'unlocked');
						status[Shop.selection] = localStorage.getItem('bus5');
						Shop.prices[Shop.selection] = 'Selected';
						this.label(pricetag);
						break;
					case 5:
						localStorage.setItem('bus6', 'unlocked');
						status[Shop.selection] = localStorage.getItem('bus6');
						Shop.prices[Shop.selection] = 'Selected';
						this.label(pricetag);
						break;
				};
				Shop.prices[Shop.selection] = 'Selected';
				coins.setText("Coins = " + bank);
				this.skin(status);
			}
			else if(bank < Shop.prices[Shop.selection]){
				pricetag.x = 130;
				pricetag.setText('Not enough cash');
			}
		});

	}
	label = (pricetag, status)=>{
		if(status[Shop.selection] == 'unlocked'){
			Shop.prices[Shop.selection] = 'Selected';
		}

		if(Shop.prices[Shop.selection] != 'Selected'){
			pricetag.x = 185;
		}
		else{
			pricetag.x = 170;
		}
		pricetag.setText(Shop.prices[Shop.selection]);
	}
	skin = (status)=>{
		if(status[Shop.selection] == 'unlocked'){
			localStorage.setItem('skin', Shop.selection);
			Menu.skin = localStorage.getItem('skin');
		}
	}
}